﻿#include "zchxaisdataserver.h"
#include <QDebug>
#include <QTime>
#include "../profiles.h"
#include "ais.h"
#include "Log.h"
#include <synchapi.h>
#define cout qDebug()<< "在文件"<<__FILE__ << "第"<< __LINE__<< "行"


ZCHXAisDataServer::ZCHXAisDataServer(int id,QObject *parent) :\
    m_pTcpServer(0),
    m_pTcpSocket(0),
    mAisHeartTimer(0),
    mLastRecvAisDataTime(0),
    QObject(parent)
{
    QString str_ais = QString("Ais_") + QString::number(id);
    m_bServer = Utils::Profiles::instance()->value(str_ais,"IsServer").toBool();
    m_uServerPort = Utils::Profiles::instance()->value(str_ais,"Server_Port").toInt();
    m_sIP = Utils::Profiles::instance()->value(str_ais,"IP").toString();
    m_uPort = Utils::Profiles::instance()->value(str_ais,"Port").toInt();
    mDataTimeOut = Utils::Profiles::instance()->value(str_ais, "TimeOut", 1).toInt();
    mAisHeartTimer = new QTimer();
    mAisHeartTimer->setInterval(60*1000);
    connect(mAisHeartTimer, SIGNAL(timeout()), this, SLOT(slotCheckAisRecv()));
    connect(this,SIGNAL(startProcessSignal()),this,SLOT(startProcessSlot()));
    moveToThread(&m_workThread);

    m_workThread.start();
    mAisHeartTimer->start();

}

ZCHXAisDataServer::~ZCHXAisDataServer()
{
    qDebug()<<"~ZCHXAisDataServer()_11";
    if(m_workThread.isRunning())
    {
        m_workThread.quit();
    }
    m_workThread.terminate();

    if(m_pTcpServer)
    {
        delete m_pTcpServer;
        m_pTcpServer = NULL;
    }
    if(m_pTcpSocket)
    {
        delete m_pTcpSocket;
        m_pTcpSocket = NULL;
    }
}

void ZCHXAisDataServer::startProcessSlot()
{
    init();
}

void ZCHXAisDataServer::init()
{
    LOG(LOG_RTM, "%s %s %d,socket = %0x",__FILE__,__FUNCTION__, __LINE__,m_pTcpSocket);
    if(m_bServer)
    {
        LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
        if(m_pTcpServer)
        {
            m_pTcpServer->close();
            delete m_pTcpServer;
            m_pTcpServer = 0;
        }
        LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
        m_pTcpServer = new QTcpServer();
        connect(m_pTcpServer,SIGNAL(newConnection()),this,SLOT(acceptConnection()));\
        connect(m_pTcpServer, SIGNAL(acceptError(QAbstractSocket::SocketError)),\
                this, SLOT(displayError(QAbstractSocket::SocketError)));
        m_pTcpServer->listen(QHostAddress::Any,m_uServerPort);
        LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
    }
    else
    {
        LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
        if(m_pTcpSocket)
        {
            LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
            m_pTcpSocket->abort();
            delete m_pTcpSocket;
            m_pTcpSocket = 0;
            LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
        }
        LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
        m_pTcpSocket = new QTcpSocket();
        LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
        //connect(m_pTcpSocket, SIGNAL(disconnected()), this, SLOT(OnSocketDisconnected()));
        connect(m_pTcpSocket,SIGNAL(readyRead()),this,SLOT(updateServerProgress()));
        connect(m_pTcpSocket,SIGNAL(error(QAbstractSocket::SocketError)),this,SLOT(displayError(QAbstractSocket::SocketError)));
        connect(m_pTcpSocket, SIGNAL(stateChanged(QAbstractSocket::SocketState)), this, SLOT(stateChanged(QAbstractSocket::SocketState)));
        m_pTcpSocket->connectToHost(m_sIP,m_uPort);
        LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);

    }
    LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
    BuildNmeaLookup();
    LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);

    m_lastClearAISTime = 0;
    mLastRecvAisDataTime = QDateTime::currentMSecsSinceEpoch();
    LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
}

void ZCHXAisDataServer::displayError(QAbstractSocket::SocketError error)
{
    if(m_bServer)
    {
        if(m_pTcpServer)
            emit signalSocketMsg(QString("ZCHXAisDataServer(Server):%1").arg(m_pTcpServer->errorString()));
    } else
    {
        if(m_pTcpSocket)
            emit signalSocketMsg(QString("ZCHXAisDataServer(Client):%1").arg(m_pTcpSocket->errorString()));
    }
}

void ZCHXAisDataServer::updateServerProgress()
{
    if(m_pTcpSocket == NULL)
    {
        return;
    }
    QByteArray aisArray = m_pTcpSocket->readAll();
    Sleep(200);
    emit signalSendAisData(aisArray);
    qint64 utc = QDateTime::currentMSecsSinceEpoch();
    QString sContent = tr("receive ais data,size = %1").arg(aisArray.size());
    emit signalSendRecvedContent(utc,"AIS_RECEIVE",sContent);
    mLastRecvAisDataTime = QDateTime::currentMSecsSinceEpoch();
}

void ZCHXAisDataServer::acceptConnection()
{
    if(m_pTcpServer == NULL)
    {
        return;
    }
    m_pTcpSocket = m_pTcpServer->nextPendingConnection();
    connect(m_pTcpSocket,SIGNAL(readyRead()),this,SLOT(updateServerProgress()));
}

void ZCHXAisDataServer::stateChanged(QAbstractSocket::SocketState state)
{
    if(state == QAbstractSocket::SocketState::ConnectedState)
    {
         LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
        emit signalSocketMsg(QString("ZCHXAisDataServer(Client): connect server success."));
    } else if(state == QAbstractSocket::SocketState::UnconnectedState)
    {
         LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
        emit signalSocketMsg(QString("ZCHXAisDataServer(Client): disconnect server"));
        cout<<"disconnect server";
        //init();
    }
}

void ZCHXAisDataServer::slotCheckAisRecv()
{
    //1分钟未接收到数据就重连
    if(QDateTime::currentMSecsSinceEpoch() - mLastRecvAisDataTime > mDataTimeOut *60 *1000 )
    {
        LOG(LOG_RTM, "last recv time:%s, now:%s, now reconnect.",\
            QDateTime::fromMSecsSinceEpoch(mLastRecvAisDataTime).toString("yyyy-MM-dd hh:mm:ss").toStdString().data(),\
            QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss").toStdString().data()
            );
        emit signalSocketMsg(QString("ZCHXAisDataServer: receive data timeout. reconnect now."));
        init();
         LOG(LOG_RTM, "%s %s %d,socket = %0x", __FILE__, __FUNCTION__,__LINE__, m_pTcpSocket);
    }
}

