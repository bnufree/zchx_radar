#include "zchxradarprocessthread.h"

ZCHXRadarProcessThread::ZCHXRadarProcessThread(QObject *parent) : QObject(parent)
{

}
