#include "common.h"


Common::Common()
{
}
