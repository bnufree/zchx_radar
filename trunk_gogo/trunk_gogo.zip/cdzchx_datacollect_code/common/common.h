﻿#ifndef COMMON_H
#define COMMON_H

#include "common_global.h"

//CRC校验


#endif // COMMON_H
