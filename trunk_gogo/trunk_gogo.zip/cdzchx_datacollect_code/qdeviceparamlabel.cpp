#include "qdeviceparamlabel.h"

QDeviceParamLabel::QDeviceParamLabel(QWidget *parent) : QLabel(parent)
{

}
