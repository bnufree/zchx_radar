#ifndef QDEVICEPARAMLABEL_H
#define QDEVICEPARAMLABEL_H

#include <QLabel>

class QDeviceParamLabel : public QLabel
{
    Q_OBJECT
public:
    explicit QDeviceParamLabel(QWidget *parent = 0);

signals:

public slots:
};

#endif // QDEVICEPARAMLABEL_H
