static const double kDefaultAlpha = 1.6;
