static const int kDefaultRank = 50;
static const int kDefaultSize = 64;
static const double kDefaultAlpha = 1.5;
