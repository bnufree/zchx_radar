#include "PastBuffer.h"

using namespace ZCHX::Algorithms;
