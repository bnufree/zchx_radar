static const int kDefaultNumScans = 2;
static const double kDefaultSearchRadius = 5;
