static const int kDefaultThreshold = 2400;
