static const int kDefaultNumScans = 2;
static const double kDefaultSearchRadius = 5;
static const double kDefaultMinRange = 50.0;
