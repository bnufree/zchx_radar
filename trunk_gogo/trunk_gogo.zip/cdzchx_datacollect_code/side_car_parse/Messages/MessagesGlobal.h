#pragma once
#include <QLoggingCategory>
#include "common.h"

Q_DECLARE_LOGGING_CATEGORY(radarmsg)
