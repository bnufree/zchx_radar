#include "up_ais_pthread.h"
#include <QThread>
#include <QFile>
#include <QString>
#include <QDialog>
#include <QFileDialog>
#include <QDebug>
#include "profiles.h"
#define cout qDebug()<< "在文件"<<__FILE__ << "第"<< __LINE__<< "行"
up_ais_pthread::up_ais_pthread(QString filename,QObject *parent) : file_name(filename),QThread(parent)
{

}

void up_ais_pthread::run()
{
    QFile ais_file(file_name);
    if(!ais_file.open(QIODevice::ReadOnly)){
           //ReadOnly文件不存在，打开失败
           //WriteOnly文件不存在，会自动创建文件
           //ReadWrite文件不存在，会自动创建文件
           //Append文件不存在，会自动创建文件
           //Truncate文件不存在，打开失败
           //Text文件不存在，打开失败
           //Unbuffered文件不存在，打开失败
           cout<<"打开失败";
       }else{
           cout<<"打开成功";

           //操作文件
           int a =17160;
           while (a)
           {
               QString ais_str = ais_file.readLine();
               QByteArray ais_array;
               ais_array = ais_str.toLatin1();
               a = ais_str.size();
               if(a != 0)
               {
                   int frequency =  Utils::Profiles::instance()->value("Ais","Ais_Send_Frequency").toInt();
                   if (frequency < 10) frequency = 10;

                   msleep(frequency);
                   cout<<"发送AIS数据";
                   emit send_ais_signal(ais_array);
                    //break;
               }
               if(ais_file.atEnd())
               {
                   cout<<"解析完毕";
                   ais_file.seek(0);
               }
           }
       }

       //关闭文件
       ais_file.close();

    this->exec();
}
