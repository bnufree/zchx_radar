#ifndef UP_AIS_PTHREAD_H
#define UP_AIS_PTHREAD_H

#include <QObject>
#include <QThread>

class up_ais_pthread : public QThread
{
    Q_OBJECT
public:
     up_ais_pthread(QString filename,QObject *parent = 0);
     void run();
signals:
     void send_ais_signal(QByteArray);//导入AIS数据

public slots:

private:
     QString file_name;
};
#endif // UP_AIS_PTHREAD_H
